from django.shortcuts import render,redirect

from django.views.generic import CreateView,ListView,DetailView,View,UpdateView
from master.models import FeedbackModel,Catagories,BookCtagoryModel
from master.forms import FeedbackForm,CatagoriesForm,BookCatagoryForm

# Create your views here.

class CreateFeedbackView(CreateView):
	template_name = 'create_feedback.html'
	model = FeedbackModel
	form_class = FeedbackForm
	success_url = '/gen/home/'

class ListFeedbackView(ListView):
	template_name = 'list_feedback.html'
	model = FeedbackModel
	context_object_name = 'feedbacks'

class CreateCatagoriesView(CreateView):	
	template_name = 'catagories.html'
	model = Catagories
	form_class = CatagoriesForm
	success_url = '/gen/home/'

class FeedbackDetailView(DetailView):
	template_name = 'feedback_detail.html'
	model = FeedbackModel
		
class ListCatagoriesView(ListView):
	template_name = 'catagories_list.html'
	model = Catagories
	context_object_name = 'catagories'

class CatagoriesDetailView(DetailView):
	template_name = 'catagories_details.html'
	model = Catagories

class NewBookCatagoryView(View):
	template_name = 'new_book_catagory.html'
	form_class = BookCatagoryForm

	def get(self,request):
		form = self.form_class()
		context = {
		'cat_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			book_cat = BookCtagoryModel.objects.create(
				title = request.POST.get('title'),
				discription = request.POST.get('discription'),
				cat_code = request.POST.get('cat_code')
				)	
			return redirect('/gen/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})	

class UpdateCatagoriesView(UpdateView):
	template_name = 'update_catagories.html'
	fields = ['title','discription']
	model = Catagories
	success_url = '/gen/home/'		


class ListBookCatagoriesView(View):
	template_name = 'list_bk_catagory.html'

	def get(self,request):
		bk_catgry = BookCtagoryModel.objects.all()
		context = {
		'catgry' :bk_catgry
		}
		return render(request,self.template_name,context)	

class BookCatagoryView(View):
	template_name = 'bk_catgry_details.html'	

	def get(self,request,pk):
		obj = BookCtagoryModel.objects.get(id=pk)
		context = {
		'catgry' :obj
		}
		return render(request,self.template_name,context)		

class DeleteBookcatagoryView(View):
	template_name = 'list_bk_catagory.html'

	def get(self,request,pk):
		cat_obj = BookCtagoryModel.objects.get(id=pk).delete()
		bk_catgry = BookCtagoryModel.objects.all()
		context = {
		'catgry' :bk_catgry
		}
		return render(request,self.template_name,context)

		