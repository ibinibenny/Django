from django.db import models

# Create your models here.


class ContactusModel(models.Model):
    name = models.CharField(max_length=25)
    email = models.EmailField()
    subject = models.CharField(max_length=30)
    message = models.TextField(max_length=500)
    place = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return self.name


class CategoryModel(models.Model):
    ptype = models.CharField(max_length=30)
    description = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.product_type


class BookCategoryModel(models.Model):
    title = models.CharField(max_length=30, null=True, blank=True)
    cat_code = models.IntegerField(default=1011)
    description = models.TextField(max_length=400)
    status = models.BooleanField(default=True)
    created_on = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title


class BooksModel(models.Model):
    title = models.ForeignKey(BookCategoryModel,on_delete=models.CASCADE)
    description = models.TextField(max_length=300)
    author = models.CharField(max_length=30)
    price = models.IntegerField()
    publisher = models.CharField(max_length=30)
    #pub_date = models.DateField()
    coverimg = models.ImageField(upload_to='media/')
    pubagrmnt = models.FileField(upload_to='media/')
    status = models.BooleanField(default=True)
    created_on = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.description
