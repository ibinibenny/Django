from django import forms

from master.models import ContactusModel, CategoryModel, BookCategoryModel, BooksModel


class ContactusForm(forms.ModelForm):
    class Meta:
        model = ContactusModel
        fields = ['name', 'email', 'subject', 'message', 'place']


class CategoryForm(forms.ModelForm):
    class Meta:
        model = CategoryModel
        fields = ['ptype', 'description']


class BookCategoryForm(forms.ModelForm):
    class Meta:
        model = BookCategoryModel
        exclude = ('status', 'created_on')


class BooksForm(forms.ModelForm):
    class Meta:
        model = BooksModel
        exclude = ('status','created_on')
