from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings

from customer.views import CustomerRegister,Customerlist

from django.contrib.auth import views as auth_views

urlpatterns = [
    path(r'register/',CustomerRegister.as_view(),name='cust_reg'),
    path(r'customerlist/',Customerlist.as_view(),name='cust_list'),
    path(r'login/', auth_views.LoginView.as_view(template_name="login.html"), name='login'),
   	path(r'logout/', auth_views.LogoutView.as_view(), name='logout'), 

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)